# Movies reviews
A collection of posts concerning movies reviews provided by around 500 users were classified into negative and positive referring to bad and good critics respectively.
The set of reviews classified as negative are within the neg folder, and the rest within the pos folder.

# Content:
The data set was split into three sets: 
· train
· dev
· test: the test set is blind (the class is unknown)

# Goal: classify the test set
